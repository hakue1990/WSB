﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Microsoft.Office.Interop;
using Excel = Microsoft.Office.Interop;
namespace excel
{
    class Program
    {
        static void openFile()
        {
            string path = @"‪C:\xampp\htdocs\git3\21._22.12.2019\newxlx.ods";
            Excel.Application excelApp = new Excel.Application();
            excelApp.Visible = true;

            Excel.Workbooks books = excelApp.Workbooks;
            Excel.Worbook sheet = books.open(path);
        }
        static void Main(string[] args)
        {
        }
    }
}
